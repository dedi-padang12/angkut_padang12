<?php
	define('DB_USERNAME','tenj4919_bang');
	define('DB_PASSWORD','angkutan');
	define('DB_NAME','tenj4919_bang');
	define('DB_HOST','localhost');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AIzaSyDV4y2QnwsDerR_BWLUnNPUBnQaS-fbdMc');
