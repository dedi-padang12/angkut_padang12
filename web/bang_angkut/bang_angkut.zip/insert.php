<?php

include 'koneksi.php';

 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);

 $nama       = $_POST['nama'];
 $no_hp    = $_POST['no_hp'];
 $email      = $_POST['email'];
 $password     = $_POST['pass'];
 $alamat      = $_POST['alamat'];
 $lokasi    =  $_POST['lokasi'];
$tgl_now = date("Y-m-d");
 $Sql_Query = "INSERT INTO pelanggan  VALUES('','$nama', '$no_hp', '$email', '$password', '$alamat','$lokasi','$tgl_now')";

 if(mysqli_query($con,$Sql_Query)){

 echo 'Data Inserted Successfully';

 }
 else{

 echo 'Try Again';

 }
 mysqli_close($con);
?>
