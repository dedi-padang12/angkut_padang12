package com.angkut.pelangganp12;

public class Server {
    public static final String URL = "http://192.168.1.4/bang_angkut/";
}