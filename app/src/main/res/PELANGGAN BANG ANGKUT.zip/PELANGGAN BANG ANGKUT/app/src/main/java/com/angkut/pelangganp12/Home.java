package com.angkut.pelangganp12;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.angkut.pelangganp12.dataOrder.ListActivity;
import com.angkut.pelangganp12.dataOrder.RequestHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.view.MenuItem;
import java.util.ArrayList;
import java.util.HashMap;

public class Home extends AppCompatActivity implements ModalOrder.BottomSheetListener, ModalOrderMobil.BottomSheetListener2 {

//flas
ImageView bgapp, clover;
    LinearLayout textsplash, texthome, menus;
    Animation frombottom;
    //end
    Button btn_logout;
    TextView txt_id, txt_email,txt_jarak;
    String id_pelanggan, email;
    SharedPreferences sharedpreferences;

    public static final String TAG_ID = "id_pelanggan";
    public static final String TAG_EMAIL = "email";
    public static final String TAG_JARAK = "jarak";
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    ArrayList<HashMap<String, String>> list_data;
    String jarak_tempuh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        txt_id = (TextView) findViewById(R.id.txt_id);
        txt_email = (TextView) findViewById(R.id.txt_email);
        btn_logout = (Button) findViewById(R.id.btn_logout);
        txt_jarak = (TextView) findViewById(R.id.txt_jarak);
        sharedpreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);

        id_pelanggan = getIntent().getStringExtra(TAG_ID);
        email = getIntent().getStringExtra(TAG_EMAIL);
        jarak_tempuh = getIntent().getStringExtra(TAG_JARAK);
        //txt_id.setText("ID : " + id);
        txt_email.setText("EMAIL : " + email);
        //tampil data pelanggan
        list_data = new ArrayList<HashMap<String, String>>();

        String url = "http://192.168.1.4/bang_angkut/tampil_pelanggan.php?id="+id_pelanggan;

        stringRequest = new StringRequest( Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("tampil_pelanggan");
                    for (int a = 0; a < jsonArray.length(); a ++){
                        JSONObject json = jsonArray.getJSONObject(a);
                        HashMap<String, String> map  = new HashMap<String, String>();

                        map.put("jarak", json.getString("jarak"));


                        list_data.add(map);
                    }

                    jarak_tempuh = list_data.get(0).get("jarak");
                    txt_jarak.setText("jarak : " + jarak_tempuh);
// mTextView = findViewById(R.id.txt_order_motor);
                    Button ModalOrder = findViewById(R.id.btn_order_motor);
                    ModalOrder.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {

                            ModalOrder bottomSheet = new ModalOrder();
                            bottomSheet.show(getSupportFragmentManager(), "exampleBottomSheet");

                            Intent intent = new Intent(Home.this, ModalOrder.class);
                            intent.putExtra(TAG_ID, id_pelanggan);
                            intent.putExtra(TAG_EMAIL, email);
                            intent.putExtra("jarak_tempuh", jarak_tempuh);

                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }


        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Home.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestHandler.getInstance(Home.this).addToRequestQueue(stringRequest);
//end tampil pelanggan

        btn_logout.setOnClickListener(new View.OnClickListener() {
//
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // update login session ke FALSE dan mengosongkan nilai id dan email
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putBoolean(Login.session_status, false);
                editor.putString(TAG_ID, null);
                editor.putString(TAG_EMAIL, null);
                editor.commit();

                Intent intent = new Intent(Home.this, Login.class);
                finish();
                startActivity(intent);
            }
        });
        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);


        bgapp = (ImageView) findViewById(R.id.bgapp);
        clover = (ImageView) findViewById(R.id.clover);
        textsplash = (LinearLayout) findViewById(R.id.textsplash);
        texthome = (LinearLayout) findViewById(R.id.texthome);
        menus = (LinearLayout) findViewById(R.id.menus);

        bgapp.animate().translationY(-1900).setDuration(800).setStartDelay(300);
        clover.animate().alpha(0).setDuration(800).setStartDelay(600);
        textsplash.animate().translationY(140).alpha(0).setDuration(800).setStartDelay(300);

        texthome.startAnimation(frombottom);
        menus.startAnimation(frombottom);

        //modal order


        Button ModalOrderMobil = findViewById(R.id.btn_order_mobil);
        ModalOrderMobil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ModalOrderMobil bottomSheet = new ModalOrderMobil();
                bottomSheet.show(getSupportFragmentManager(), "exampleBottomSheet");
            }
        });

        Button btn_order = findViewById(R.id.btn_order);
        btn_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, ListActivity.class);
                intent.putExtra("id_pelanggan", id_pelanggan);

                startActivity(intent);
            }
        });

    }


    @Override
    public void onButtonClicked(String text) {

    }

}